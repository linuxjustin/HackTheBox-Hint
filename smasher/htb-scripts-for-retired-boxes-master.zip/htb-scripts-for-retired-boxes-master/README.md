# HTB Scripts for Retired Boxes

Just a place to share some things I've written while participating in Hack The Box.

1. [Tartarsauce inotify solution](https://gitlab.com/epi052/htb-scripts-for-retired-boxes/tree/master/tartarsauce)
2. [Jerry - Tomcat default credentials login](https://gitlab.com/epi052/htb-scripts-for-retired-boxes/tree/master/jerry)
